# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.http import Http404
from django.shortcuts import render

from main.models import Floare


# Create your views here.
def index(request):
    # vedem obiectele care sunt la oferta - au discount

    intrari = Floare.objects.filter(discount=True)

    return render(request, 'index.html', {'entryS': intrari})


def entry_detail(request, id):
    try:
        myID = Floare.objects.filter(id=id)
    except:
        raise Http404("Numele nu exista")

    else:
        return render(request, 'entry_detail.html', {'myID': myID})

def entry_all(request):
    #listare obiecte
    flori = Floare.objects.all()
    return render(request,'all.html', {'florS': flori})



def contact(request):
    return render(request, 'contact.html', {})


