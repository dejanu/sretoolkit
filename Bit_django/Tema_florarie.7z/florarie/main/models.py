# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models


# Create your models here.
class Floare(models.Model):
    """blueprint for flower objects"""

    name = models.CharField(max_length=30)
    description = models.TextField()
    price = models.IntegerField(default=10)
    # widget for this field is a CheckboxInput
    discount = models.BooleanField()
    price_d = models.IntegerField(default = 5)
    #numar bucati
    items_no = models.IntegerField(default=10)


