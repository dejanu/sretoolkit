# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def index(request):
    return HttpResponse('<p>Index view</p>')


def entry_detail(request,nume):
    return HttpResponse('<p>entry_detail cu "'+nume+'"</p>')

##################################################################
from django.http import Http404
from main.models import Student

def index(request):
    intrari=Student.objects.all()
    return render(request,'index.html',{'entryS':intrari})


def entry_detail(request,nume):
    try:
        myID=Student.objects.get(id=nume)
    except:
        raise Http404("Intrare nu exista!!!")
    else:
        return render(request,'entry_detail.html',{'myID':myID,'fisier':myID.proiect.read()})


def contact(request):
    return render(request, 'contact.html', {})
