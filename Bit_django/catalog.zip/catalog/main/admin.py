# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from main.models import Student
# Register your models here.

class studentAdmin(admin.ModelAdmin):
     list_display = ["nume","nota","email"]

admin.site.register(Student,studentAdmin)
