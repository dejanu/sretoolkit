# Program kivy11
# Explica functiile kivy -  audio widget
# Ion Studentul - 1/26/13

from kivy.core.audio import SoundLoader
from kivy.uix.gridlayout import GridLayout
from kivy.app import App

class VideoPlayerApp(App):

    def build(self):
        global s
        layout= GridLayout()
        cols=1
        sound = SoundLoader.load('JO_-_09_-_Fortitude.ogg')
        s=sound
        sound.play()
        print "Sursa fisierului este", sound.source
        print "Lungimea fisierului este ", sound.length
        #return layout

if __name__ == '__main__':
    VideoPlayerApp().run()



    
